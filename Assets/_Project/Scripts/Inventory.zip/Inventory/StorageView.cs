using System;
using System.Collections;
using System.Linq;
using UnityEngine;
using UnityEngine.UI;

namespace Timelesss
{
    public abstract class StorageView : MonoBehaviour
    {
        public Slot[] Slots;
        [SerializeField] protected GameObject ghostIconObject; 
        protected RectTransform ghostIcon;
        static bool isDragging;
        static Slot originalSlot;
        public event Action<Slot, Slot> OnDrop;

        void Start()
        {
            // GameObject의 RectTransform 가져오기
            if (ghostIconObject)
                ghostIcon = ghostIconObject.GetComponent<RectTransform>();
            
            ghostIcon.gameObject.SetActive(false); // 기본적으로 비활성화
            foreach (var slot in Slots)
            {
                slot.OnStartDrag += OnPointerDown;
            }
        }
        
        public abstract IEnumerator InitializeView(ViewModel viewModel);
        void OnPointerDown(Vector2 position, Slot slot)
        {
            isDragging = true;
            originalSlot = slot;
            StartCoroutine(FollowMouse());
            // Ghost 아이콘 초기화
            SetupGhostIcon(slot);
        }
        
        void OnPointerUp()
        {
            if (!isDragging) return;
            var closestSlot = Slots
                .Where(slot => RectTransformUtility.RectangleContainsScreenPoint(slot.RectTransform, Input.mousePosition))
                .OrderBy(slot => Vector2.Distance(slot.RectTransform.position, Input.mousePosition))
                .FirstOrDefault();
            if (closestSlot != null)
            {
                OnDrop?.Invoke(originalSlot, closestSlot);
            }
            else
            {
                // 원래 슬롯 아이콘 복구
                originalSlot.Icon.sprite = originalSlot.BaseSprite;
            }
            isDragging = false;
            originalSlot = null;
            ghostIcon.gameObject.SetActive(false); // Ghost 아이콘 숨김
        }
        
        IEnumerator FollowMouse()
        {
            while (isDragging)
            {
                Vector2 mousePosition = Input.mousePosition;
         
                // Screen 좌표계를 UI 형식으로 변환
                RectTransformUtility.ScreenPointToLocalPointInRectangle(
                    ghostIcon.parent as RectTransform, 
                    mousePosition,
                    null, 
                    out var uiPosition
                );
                // Ghost 아이콘 위치 지정
                SetGhostIconPosition(uiPosition);
                yield return null;
            }
        }
        void SetupGhostIcon(Slot slot)
        {
            ghostIcon.gameObject.SetActive(true);
            // Ghost 아이콘의 비주얼 설정
            var ghostImage = ghostIcon.GetComponent<Image>();
            ghostImage.sprite = slot.BaseSprite;
            originalSlot.Icon.sprite = null; // 드래그 시작 시 아이템 아이콘 숨기기
        }
        void SetGhostIconPosition(Vector2 position)
        {
            // RectTransform을 통해 위치를 설정
            ghostIcon.anchoredPosition = position - new Vector2(ghostIcon.sizeDelta.x / 2, ghostIcon.sizeDelta.y / 2);
        }
    }
}

// namespace Systems.Inventory
// {
//     public abstract class StorageView : MonoBehaviour
//     {
//         public Slot[] Slots;
//
//         [SerializeField] protected GameObject ghostIconObject; // 이제 GameObject로 변환
//         protected RectTransform ghostIcon;
//
//         static bool isDragging;
//         static Slot originalSlot;
//
//         public event Action<Slot, Slot> OnDrop;
//
//         void Start()
//         {
//             // GameObject의 RectTransform 가져오기
//             if (ghostIconObject != null)
//                 ghostIcon = ghostIconObject.GetComponent<RectTransform>();
//
//             ghostIcon.gameObject.SetActive(false); // 기본적으로 비활성화
//
//             foreach (var slot in Slots)
//             {
//                 slot.OnStartDrag += OnPointerDown;
//             }
//         }
//
//         public abstract IEnumerator InitializeView(ViewModel viewModel);
//
//         void OnPointerDown(Vector2 position, Slot slot)
//         {
//             isDragging = true;
//             originalSlot = slot;
//
//             StartCoroutine(FollowMouse());
//
//             // Ghost 아이콘 초기화
//             SetupGhostIcon(slot);
//         }
//
//         void OnPointerUp()
//         {
//             if (!isDragging) return;
//
//             var closestSlot = Slots
//                 .Where(slot => RectTransformUtility.RectangleContainsScreenPoint(slot.RectTransform, Input.mousePosition))
//                 .OrderBy(slot => Vector2.Distance(slot.RectTransform.position, Input.mousePosition))
//                 .FirstOrDefault();
//
//             if (closestSlot != null)
//             {
//                 OnDrop?.Invoke(originalSlot, closestSlot);
//             }
//             else
//             {
//                 // 원래 슬롯 아이콘 복구
//                 originalSlot.IconImage.sprite = originalSlot.BaseSprite;
//             }
//
//             isDragging = false;
//             originalSlot = null;
//             ghostIcon.gameObject.SetActive(false); // Ghost 아이콘 숨김
//         }
//
//         IEnumerator FollowMouse()
//         {
//             while (isDragging)
//             {
//                 Vector2 mousePosition = Input.mousePosition;
//                 
//                 // Screen 좌표계를 UI 형식으로 변환
//                 Vector2 uiPosition;
//                 RectTransformUtility.ScreenPointToLocalPointInRectangle(
//                     ghostIcon.parent as RectTransform, 
//                     mousePosition,
//                     null, 
//                     out uiPosition
//                 );
//
//                 // Ghost 아이콘 위치 지정
//                 SetGhostIconPosition(uiPosition);
//                 yield return null;
//             }
//         }
//
//         void SetupGhostIcon(Slot slot)
//         {
//             ghostIcon.gameObject.SetActive(true);
//
//             // Ghost 아이콘의 비주얼 설정
//             var ghostImage = ghostIcon.GetComponent<UnityEngine.UI.Image>();
//             ghostImage.sprite = slot.BaseSprite;
//             originalSlot.IconImage.sprite = null; // 드래그 시작 시 아이템 아이콘 숨기기
//         }
//
//         void SetGhostIconPosition(Vector2 position)
//         {
//             // RectTransform을 통해 위치를 설정
//             ghostIcon.anchoredPosition = position - new Vector2(ghostIcon.sizeDelta.x / 2, ghostIcon.sizeDelta.y / 2);
//         }
//     }
// }