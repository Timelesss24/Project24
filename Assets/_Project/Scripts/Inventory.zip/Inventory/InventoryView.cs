using System.Collections;
using Systems.Inventory;
using TMPro;
using UnityEngine;
using UnityEngine.UI;

namespace Timelesss
{
    public class InventoryView : StorageView
    {
        [SerializeField] string panelName = "인벤토리";
        [SerializeField] GameObject slotPrefab; // 슬롯 프리팹
        [SerializeField] Transform slotsParent; // 슬롯 부모 컨테이너
        [SerializeField] GameObject ghostIconPrefab; // 고스트 아이콘 프리팹
        [SerializeField] Button closeButton; // 닫기 버튼
        [SerializeField] TextMeshProUGUI inventoryHeader; // 제목 텍스트

        public override IEnumerator InitializeView(ViewModel viewModel)
        {
            // 슬롯 배열 초기화
            Slots = new Slot[viewModel.Capacity];

            // 제목 설정
            inventoryHeader.text = panelName;

            // 슬롯 영역 UI 생성
            for (int i = 0; i < viewModel.Capacity; i++)
            {
                // 슬롯 프리팹 생성 및 부모 컨테이너에 추가
                var slotObject = Instantiate(slotPrefab, slotsParent);
                var slotComponent = slotObject.GetComponent<Slot>();

                Slots[i] = slotComponent;
                slotComponent.Initialize(i); // 초기화 (예: 인덱스 설정)
            }

            // 고스트 아이콘 생성
            if (ghostIconPrefab != null)
            {
                var ghostIconObject = Instantiate(ghostIconPrefab, transform);
                ghostIcon = ghostIconObject.GetComponent<RectTransform>();
                ghostIcon.gameObject.SetActive(false); // 기본적으로 비활성화
            }

            // 닫기 버튼 이벤트 연결
            closeButton.onClick.AddListener(() =>
            {
                // UI 매니저 등을 통해 창 닫기 처리
                Debug.Log($"Closing {panelName}.");
            });

            yield return null;
        }
    }
}